import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { format, startOfDay, endOfDay, getDay, parse, isWithinInterval } from 'date-fns';
import { fetchAndParseCSV, RawVisitorData } from '../services/csvService';
import { fetchWeatherData, ProcessedWeatherData } from '../services/weatherService';
import { HourlyData, DailyData } from '../types/analytics';

interface BusinessHours {
  start: string;
  end: string;
}

const BUSINESS_HOURS: { [key: number]: BusinessHours } = {
  0: { start: '08:00', end: '16:00' }, // Sunday
  1: { start: '07:00', end: '20:00' }, // Monday
  2: { start: '07:00', end: '20:00' }, // Tuesday
  3: { start: '07:00', end: '20:00' }, // Wednesday
  4: { start: '07:00', end: '20:00' }, // Thursday
  5: { start: '07:00', end: '20:00' }, // Friday
  6: { start: '08:00', end: '20:00' }, // Saturday
};

interface DataContextType {
  hourlyData: HourlyData[];
  dailyData: DailyData[];
  isLoading: boolean;
  error: string | null;
  retryFetch: () => void;
}

const DataContext = createContext<DataContextType>({
  hourlyData: [],
  dailyData: [],
  isLoading: true,
  error: null,
  retryFetch: () => {},
});

export const useData = () => useContext(DataContext);

interface DataProviderProps {
  children: ReactNode;
}

export const DataProvider = ({ children }: DataProviderProps) => {
  const [hourlyData, setHourlyData] = useState<HourlyData[]>([]);
  const [dailyData, setDailyData] = useState<DailyData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);

  const isWithinBusinessHours = (timestamp: Date): boolean => {
    const dayOfWeek = getDay(timestamp);
    const hours = BUSINESS_HOURS[dayOfWeek];
    
    const timeStr = format(timestamp, 'HH:mm');
    const currentTime = parse(timeStr, 'HH:mm', new Date());
    const openTime = parse(hours.start, 'HH:mm', new Date());
    const closeTime = parse(hours.end, 'HH:mm', new Date());

    return isWithinInterval(currentTime, { start: openTime, end: closeTime });
  };

  const retryFetch = () => {
    setRetryCount(count => count + 1);
    setError(null);
    setIsLoading(true);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        // Fetch CSV data with retry logic
        const csvUrl = 'https://raw.githubusercontent.com/JFT51/ExRest/refs/heads/main/ikxe.csv';
        let visitorData: RawVisitorData[] | null = null;
        let csvError: Error | null = null;

        for (let i = 0; i < 3; i++) {
          try {
            visitorData = await fetchAndParseCSV(csvUrl);
            if (visitorData && visitorData.length > 0) break;
          } catch (e) {
            csvError = e as Error;
            await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1))); // Exponential backoff
          }
        }

        if (!visitorData || visitorData.length === 0) {
          throw new Error(csvError?.message || 'Failed to fetch visitor data after multiple attempts');
        }

        // Get date range for weather data
        const startDate = format(visitorData[0].timestamp, 'yyyy-MM-dd');
        const endDate = format(visitorData[visitorData.length - 1].timestamp, 'yyyy-MM-dd');
        
        // Fetch weather data with fallback handling
        let weatherData: ProcessedWeatherData[];
        try {
          weatherData = await fetchWeatherData(startDate, endDate);
        } catch (weatherError) {
          console.warn('Weather data fetch failed, using fallback data:', weatherError);
          weatherData = [];
        }

        // Process data...
        // [Rest of the data processing logic remains the same]
        
        setHourlyData(processedHourlyData);
        setDailyData(processedDailyData);
        setIsLoading(false);
        setError(null);
      } catch (err) {
        const errorMessage = err instanceof Error 
          ? err.message 
          : 'An unexpected error occurred while fetching data';
        setError(`Error: ${errorMessage}. Please try again later.`);
        setIsLoading(false);
      }
    };

    fetchData();
  }, [retryCount]);

  return (
    <DataContext.Provider value={{ hourlyData, dailyData, isLoading, error, retryFetch }}>
      {children}
    </DataContext.Provider>
  );
};