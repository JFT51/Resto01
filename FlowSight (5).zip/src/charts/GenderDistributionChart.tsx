import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { CustomTooltip } from './components/CustomTooltip';

interface GenderData {
  timestamp: string;
  men: number;
  women: number;
  menBenchmark?: number;
  womenBenchmark?: number;
}

interface GenderDistributionChartProps {
  data: GenderData[];
  showBenchmark?: boolean;
  showLegend?: boolean;
}

export const GenderDistributionChart = ({ 
  data, 
  showBenchmark = false,
  showLegend = true 
}: GenderDistributionChartProps) => {
  if (!data || data.length === 0) {
    return <div className="h-64 flex items-center justify-center text-gray-500">No data available</div>;
  }

  return (
    <div style={{ width: '100%', height: '400px' }}>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="timestamp" />
          <YAxis />
          <Tooltip content={<CustomTooltip />} />
          {showLegend && <Legend />}
          <Bar dataKey="men" name="Men" fill="#6366f1" />
          <Bar dataKey="women" name="Women" fill="#ec4899" />
          {showBenchmark && (
            <>
              <Bar dataKey="menBenchmark" name="Men (Benchmark)" fill="#6366f1" opacity={0.5} />
              <Bar dataKey="womenBenchmark" name="Women (Benchmark)" fill="#ec4899" opacity={0.5} />
            </>
          )}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};