import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { CustomTooltip } from './components/CustomTooltip';

interface CaptureRateData {
  timestamp: string;
  captureRate: number;
  captureRateBenchmark?: number;
}

interface CaptureRateChartProps {
  data: CaptureRateData[];
  showBenchmark?: boolean;
  showLegend?: boolean;
}

export const CaptureRateChart = ({ 
  data, 
  showBenchmark = false,
  showLegend = true 
}: CaptureRateChartProps) => {
  if (!data || data.length === 0) {
    return <div className="h-64 flex items-center justify-center text-gray-500">No data available</div>;
  }

  return (
    <div style={{ width: '100%', height: '400px' }}>
      <ResponsiveContainer>
        <LineChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="timestamp" />
          <YAxis />
          <Tooltip content={<CustomTooltip />} />
          {showLegend && <Legend />}
          <Line 
            type="monotone" 
            dataKey="captureRate" 
            name="Capture Rate" 
            stroke="#2A4E1E" 
            strokeWidth={2}
          />
          {showBenchmark && (
            <Line 
              type="monotone" 
              dataKey="captureRateBenchmark" 
              name="Benchmark" 
              stroke="#2A4E1E" 
              strokeWidth={2}
              strokeDasharray="5 5"
              opacity={0.5}
            />
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};