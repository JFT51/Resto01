interface TooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
}

export const CustomTooltip = ({ active, payload, label }: TooltipProps) => {
  if (!active || !payload || !payload.length) return null;

  const dataPoint = payload[0].payload;
  const hasWeather = dataPoint?.weather;

  return (
    <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
      <p className="font-medium text-gray-900 mb-2">{label}</p>
      {hasWeather && (
        <div className="mb-2 pb-2 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <span className="text-xl">
              {String.fromCodePoint(dataPoint.weather.weatherCode)}
            </span>
            <span className="text-gray-600">
              {dataPoint.weather.temperature}°C | {dataPoint.weather.precipitation}mm
            </span>
          </div>
        </div>
      )}
      {payload.map((entry: any, index: number) => (
        <div
          key={index}
          className="flex justify-between items-center gap-4"
        >
          <span style={{ color: entry.color }}>{entry.name}:</span>
          <span className="font-medium">
            {entry.name.toLowerCase().includes('rate')
              ? `${entry.value.toFixed(2)}%`
              : entry.value.toLocaleString()}
          </span>
        </div>
      ))}
    </div>
  );
};