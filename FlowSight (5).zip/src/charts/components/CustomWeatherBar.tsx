interface CustomWeatherBarProps {
  x?: number;
  y?: number;
  width?: number;
  payload?: {
    weather?: {
      weatherCode: number;
    };
  };
}

export const CustomWeatherBar = ({ x, y, width, payload }: CustomWeatherBarProps) => {
  if (!payload?.weather?.weatherCode || !x || !y || !width) return null;

  return (
    <text
      x={x + width / 2}
      y={y - 10}
      textAnchor="middle"
      fontSize="20"
      children={String.fromCodePoint(payload.weather.weatherCode)}
    />
  );
};