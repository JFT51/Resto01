import { BarChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart, Bar } from 'recharts';
import { CustomTooltip } from './components/CustomTooltip';
import { CustomWeatherBar } from './components/CustomWeatherBar';

interface ChartData {
  timestamp: string;
  visitors: number;
  visitorsBenchmark?: number;
  passersby: number;
  passersbyBenchmark?: number;
  captureRate: number;
  captureRateBenchmark?: number;
  men: number;
  menBenchmark?: number;
  women: number;
  womenBenchmark?: number;
  groups: number;
  groupsBenchmark?: number;
  weather?: {
    temperature: number;
    precipitation: number;
    weatherCode: number;
  };
}

interface VisitorTrafficChartProps {
  data: ChartData[];
  activeMetrics: string[];
  showLegend?: boolean;
  isDailyData?: boolean;
  benchmarkEnabled?: boolean;
}

const VisitorLabel = (props: any) => {
  const { x, y, value } = props;
  // Only render label if value is greater than 0
  if (value <= 0) return null;
  return (
    <text 
      x={x + props.width / 2} 
      y={y - 10} 
      fill="#000000" 
      textAnchor="middle" 
      fontSize={14}
      fontWeight="bold"
    >
      {value.toLocaleString()}
    </text>
  );
};

export const VisitorTrafficChart = ({ 
  data, 
  activeMetrics, 
  showLegend = true,
  isDailyData = false,
  benchmarkEnabled = false,
}: VisitorTrafficChartProps) => {
  if (!data || data.length === 0) {
    return <div className="h-64 flex items-center justify-center text-gray-500">No data available</div>;
  }

  const customColors = {
    visitors: '#4D8B31',
    visitorsBenchmark: '#4D8B31',
    passersby: '#FF8811',
    passersbyBenchmark: '#FF8811',
    captureRate: '#2A4E1E',
    captureRateBenchmark: '#2A4E1E',
    men: '#6366f1',
    menBenchmark: '#6366f1',
    women: '#ec4899',
    womenBenchmark: '#ec4899',
    groups: '#8b5cf6',
    groupsBenchmark: '#8b5cf6',
  };

  const renderMetric = (metric: string, benchmarkSuffix: string = '') => {
    const baseMetric = metric.replace('Benchmark', '');
    if (!activeMetrics.includes(baseMetric)) return null;

    const props = {
      type: "monotone" as const,
      dataKey: metric,
      name: `${baseMetric.charAt(0).toUpperCase() + baseMetric.slice(1)}${benchmarkSuffix}`,
      stroke: customColors[metric as keyof typeof customColors],
      fill: customColors[metric as keyof typeof customColors],
      yAxisId: baseMetric === 'passersby' ? 'passersby' : 
               baseMetric === 'captureRate' ? 'captureRate' : 'primary',
      strokeWidth: 2,
      opacity: metric.includes('Benchmark') ? 0.5 : 1,
      strokeDasharray: metric.includes('Benchmark') ? '5 5' : undefined,
      connectNulls: true,
    };

    if (metric === 'visitors' || metric === 'visitorsBenchmark') {
      return (
        <Bar
          {...props}
          strokeWidth={0}
          barSize={60}
          stackId={metric.includes('Benchmark') ? 'benchmark' : 'main'} // Add stackId
          label={metric === 'visitors' ? VisitorLabel : undefined}
        />
      );
    }

    return <Line {...props} />;
  };

  const hasWeatherData = data.some(item => item.weather);
  const chartMargin = { 
    top: 40,
    right: activeMetrics.includes('captureRate') ? 60 : 30,
    left: 0,
    bottom: 0,
  };

  return (
    <div style={{ width: '100%', height: '400px' }}>
      <ResponsiveContainer>
        <ComposedChart 
          data={data} 
          margin={chartMargin}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey={isDailyData ? 'timestamp' : 'hour'}
            tick={{ fill: '#666' }}
            tickLine={{ stroke: '#666' }}
          />

          {activeMetrics.some(m => !['passersby', 'captureRate'].includes(m)) && (
            <YAxis
              yAxisId="primary"
              tick={{ fill: '#666' }}
              tickLine={{ stroke: '#666' }}
            />
          )}

          {activeMetrics.includes('passersby') && (
            <YAxis
              yAxisId="passersby"
              orientation="right"
              tick={{ fill: '#FF8811' }}
              tickLine={{ stroke: '#FF8811' }}
            />
          )}

          {activeMetrics.includes('captureRate') && (
            <YAxis
              yAxisId="captureRate"
              orientation="right"
              tick={{ fill: '#2A4E1E' }}
              tickLine={{ stroke: '#2A4E1E' }}
            />
          )}

          <Tooltip content={<CustomTooltip />} />
          {showLegend && <Legend />}
          
          {/* Regular Metrics */}
          {renderMetric('visitors')}
          {renderMetric('passersby')}
          {renderMetric('captureRate')}
          {renderMetric('men')}
          {renderMetric('women')}
          {renderMetric('groups')}

          {/* Benchmark Metrics */}
          {benchmarkEnabled && renderMetric('visitorsBenchmark', ' (Benchmark)')}
          {benchmarkEnabled && renderMetric('passersbyBenchmark', ' (Benchmark)')}
          {benchmarkEnabled && renderMetric('captureRateBenchmark', ' (Benchmark)')}
          {benchmarkEnabled && renderMetric('menBenchmark', ' (Benchmark)')}
          {benchmarkEnabled && renderMetric('womenBenchmark', ' (Benchmark)')}
          {benchmarkEnabled && renderMetric('groupsBenchmark', ' (Benchmark)')}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};