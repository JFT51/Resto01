import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { CustomTooltip } from './components/CustomTooltip';

interface GroupsData {
  timestamp: string;
  groups: number;
  groupsBenchmark?: number;
}

interface GroupsChartProps {
  data: GroupsData[];
  showBenchmark?: boolean;
  showLegend?: boolean;
}

export const GroupsChart = ({ 
  data, 
  showBenchmark = false,
  showLegend = true 
}: GroupsChartProps) => {
  if (!data || data.length === 0) {
    return <div className="h-64 flex items-center justify-center text-gray-500">No data available</div>;
  }

  return (
    <div style={{ width: '100%', height: '400px' }}>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="timestamp" />
          <YAxis />
          <Tooltip content={<CustomTooltip />} />
          {showLegend && <Legend />}
          <Bar dataKey="groups" name="Groups" fill="#8b5cf6" />
          {showBenchmark && (
            <Bar dataKey="groupsBenchmark" name="Groups (Benchmark)" fill="#8b5cf6" opacity={0.5} />
          )}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};