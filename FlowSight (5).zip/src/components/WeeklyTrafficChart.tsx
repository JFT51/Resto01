import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { format } from 'date-fns';

interface WeatherData {
  temperature: number;
  precipitation: number;
  weatherCode: number;
}

interface WeeklyDataPoint {
  time: string;
  timestamp: string;
  visitors: number;
  visitorsBenchmark?: number;
  passersby: number;
  passersbyBenchmark?: number;
  captureRate: number;
  captureRateBenchmark?: number;
  men: number;
  menBenchmark?: number;
  women: number;
  womenBenchmark?: number;
  groups: number;
  groupsBenchmark?: number;
  weather?: WeatherData;
}

interface WeeklyTrafficChartProps {
  data: WeeklyDataPoint[];
  activeMetrics: string[];
  showLegend?: boolean;
}

const CustomWeatherBar = (props: any) => {
  const { x, y, width, value, payload } = props;
  
  if (payload?.weather?.weatherCode) {
    return (
      <text
        x={x + width / 2}
        y={y - 10}
        textAnchor="middle"
        fontSize="20"
        children={String.fromCodePoint(payload.weather.weatherCode)}
      />
    );
  }
  
  return null;
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload || !payload.length) return null;

  const dataPoint = payload[0].payload;
  const hasWeather = dataPoint?.weather;

  return (
    <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
      <p className="font-medium text-gray-900 mb-2">{label}</p>
      {hasWeather && (
        <div className="mb-2 pb-2 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <span className="text-xl">
              {String.fromCodePoint(dataPoint.weather.weatherCode)}
            </span>
            <span className="text-gray-600">
              {dataPoint.weather.temperature}°C | {dataPoint.weather.precipitation}mm
            </span>
          </div>
        </div>
      )}
      {payload.map((entry: any, index: number) => (
        <div
          key={index}
          className="flex justify-between items-center gap-4"
        >
          <span style={{ color: entry.color }}>{entry.name}:</span>
          <span className="font-medium">
            {entry.name.toLowerCase().includes('rate')
              ? `${entry.value.toFixed(2)}%`
              : entry.value.toLocaleString()}
          </span>
        </div>
      ))}
    </div>
  );
};

export const WeeklyTrafficChart = ({ 
  data, 
  activeMetrics, 
  showLegend = true,
}: WeeklyTrafficChartProps) => {
  if (!data || data.length === 0) {
    return <div className="h-64 flex items-center justify-center text-gray-500">No data available</div>;
  }

  const customColors = {
    visitors: '#4D8B31',
    visitorsBenchmark: '#4D8B31',
    passersby: '#FF8811',
    passersbyBenchmark: '#FF8811',
    captureRate: '#2A4E1E',
    captureRateBenchmark: '#2A4E1E',
    men: '#6366f1',
    menBenchmark: '#6366f1',
    women: '#ec4899',
    womenBenchmark: '#ec4899',
    groups: '#8b5cf6',
    groupsBenchmark: '#8b5cf6',
  };

  const renderMetric = (metric: string, benchmarkSuffix: string = '') => {
    const baseMetric = metric.replace('Benchmark', '');
    if (!activeMetrics.includes(baseMetric)) return null;

    const props = {
      type: "monotone" as const,
      dataKey: metric,
      name: `${baseMetric.charAt(0).toUpperCase() + baseMetric.slice(1)}${benchmarkSuffix}`,
      stroke: customColors[metric as keyof typeof customColors],
      fill: customColors[metric as keyof typeof customColors],
      yAxisId: baseMetric === 'passersby' ? 'passersby' : 
               baseMetric === 'captureRate' ? 'captureRate' : 'primary',
      strokeWidth: 2,
      opacity: metric.includes('Benchmark') ? 0.5 : 1,
      strokeDasharray: metric.includes('Benchmark') ? '5 5' : undefined,
      connectNulls: true,
    };

    if (metric === 'visitors' || metric === 'visitorsBenchmark') {
      return (
        <Bar
          {...props}
          strokeWidth={0}
          barSize={20}
          label={metric === 'visitors' ? CustomWeatherBar : undefined}
        />
      );
    }

    return <Line {...props} />;
  };

  const hasWeatherData = data.some(item => item.weather);
  const chartMargin = { 
    right: activeMetrics.includes('captureRate') ? 60 : 40, 
    top: hasWeatherData ? 40 : 10,
    left: 10, 
    bottom: 20 
  };

  return (
    <div style={{ width: '100%', height: '400px' }}>
      <ResponsiveContainer>
        <ComposedChart 
          data={data} 
          margin={chartMargin}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="time" 
            tick={{ fill: '#666' }}
            tickLine={{ stroke: '#666' }}
          />

          {activeMetrics.some(m => !['passersby', 'captureRate'].includes(m)) && (
            <YAxis
              yAxisId="primary"
              tick={{ fill: '#666' }}
              tickLine={{ stroke: '#666' }}
            />
          )}

          {activeMetrics.includes('passersby') && (
            <YAxis
              yAxisId="passersby"
              orientation="right"
              tick={{ fill: '#FF8811' }}
              tickLine={{ stroke: '#FF8811' }}
            />
          )}

          {activeMetrics.includes('captureRate') && (
            <YAxis
              yAxisId="captureRate"
              orientation="right"
              tick={{ fill: '#2A4E1E' }}
              tickLine={{ stroke: '#2A4E1E' }}
            />
          )}

          <Tooltip content={<CustomTooltip />} />
          {showLegend && <Legend />}
          
          {/* Regular Metrics */}
          {renderMetric('visitors')}
          {renderMetric('passersby')}
          {renderMetric('captureRate')}
          {renderMetric('men')}
          {renderMetric('women')}
          {renderMetric('groups')}

          {/* Benchmark Metrics */}
          {renderMetric('visitorsBenchmark', ' (Benchmark)')}
          {renderMetric('passersbyBenchmark', ' (Benchmark)')}
          {renderMetric('captureRateBenchmark', ' (Benchmark)')}
          {renderMetric('menBenchmark', ' (Benchmark)')}
          {renderMetric('womenBenchmark', ' (Benchmark)')}
          {renderMetric('groupsBenchmark', ' (Benchmark)')}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};