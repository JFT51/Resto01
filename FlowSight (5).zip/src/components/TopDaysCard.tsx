import { format, parseISO } from 'date-fns';
import { Medal } from 'lucide-react';

interface DayData {
  timestamp: string;
  value: number;
  weather?: {
    temperature: number;
    precipitation: number;
    weatherCode: number;
  };
}

interface TopDaysCardProps {
  title: string;
  data: DayData[];
  formatValue: (value: number) => string;
  icon?: React.ReactNode;
  iconColorClass?: string;
}

export const TopDaysCard = ({
  title,
  data,
  formatValue,
  icon,
  iconColorClass = "text-primary"
}: TopDaysCardProps) => {
  const medals = ["🥇", "🥈", "🥉"];

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">{title}</h2>
        <div className={iconColorClass}>
          {icon || <Medal size={24} />}
        </div>
      </div>
      <div className="space-y-4">
        {data.map((day, index) => (
          <div key={day.timestamp} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-xl">{medals[index]}</span>
              <div>
                <p className="font-medium">
                  {format(parseISO(day.timestamp), 'EEE, MMM d')}
                </p>
                {day.weather && (
                  <p className="text-sm text-gray-500">
                    {String.fromCodePoint(day.weather.weatherCode)} {day.weather.temperature}°C
                  </p>
                )}
              </div>
            </div>
            <span className="text-lg font-semibold">{formatValue(day.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};