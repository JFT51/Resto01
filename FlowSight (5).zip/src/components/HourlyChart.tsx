import { useState } from 'react';
import { BarChart, Menu } from 'lucide-react';
import { VisitorTrafficChart } from '../charts/VisitorTrafficChart';

interface HourlyData {
  timestamp: string;
  visitors: number;
  visitorsLeaving: number;
  liveVisitors: number;
  passersby: number;
  captureRate: number;
  men: number;
  women: number;
  groups: number;
  visitorsAccumulated: number;
  visitorsLeavingAccumulated: number;
  visitorsBenchmark?: number;
  passersbyBenchmark?: number;
  captureRateBenchmark?: number;
  menBenchmark?: number;
  womenBenchmark?: number;
  groupsBenchmark?: number;
  weather?: {
    temperature: number;
    precipitation: number;
    weatherCode: number;
  };
}

interface HourlyChartProps {
  mainData: HourlyData[];
  benchmarkData?: HourlyData[];
  activeMetrics: string[];
  showLegend?: boolean;
  benchmarkEnabled?: boolean;
  onMetricsChange?: (metrics: string[]) => void;
}

export const HourlyChart = ({
  mainData,
  benchmarkData,
  activeMetrics,
  showLegend = false,
  benchmarkEnabled = false,
  onMetricsChange,
}: HourlyChartProps) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const metrics = [
    { id: 'visitors', label: 'Visitors', color: '#4D8B31' },
    { id: 'passersby', label: 'Passersby', color: '#FF8811' },
    { id: 'captureRate', label: 'Capture Rate', color: '#2A4E1E' },
    { id: 'liveVisitors', label: 'Live Visitors', color: '#2A4E1E' },
    { id: 'men', label: 'Men', color: '#6366f1' },
    { id: 'women', label: 'Women', color: '#ec4899' },
    { id: 'groups', label: 'Groups', color: '#8b5cf6' },
  ];

  const toggleMetric = (metricId: string) => {
    if (!onMetricsChange) return;
    onMetricsChange(
      activeMetrics.includes(metricId)
        ? activeMetrics.filter(id => id !== metricId)
        : [...activeMetrics, metricId]
    );
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Hourly Performance</h2>
        <div className="flex items-center gap-4">
          <BarChart className="text-[#4D8B31]" />
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <Menu className="text-gray-600" />
            </button>
            
            {isMenuOpen && (
              <>
                <div 
                  className="fixed inset-0 z-10"
                  onClick={() => setIsMenuOpen(false)}
                />
                
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-100 z-20">
                  <div className="py-2">
                    {metrics.map(metric => (
                      <label
                        key={metric.id}
                        className="flex items-center px-4 py-2 hover:bg-gray-50 cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={activeMetrics.includes(metric.id)}
                          onChange={() => toggleMetric(metric.id)}
                          className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                        />
                        <div className="flex items-center gap-2 ml-3">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: metric.color }}
                          />
                          <span className="text-sm text-gray-600">{metric.label}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      
      <VisitorTrafficChart
        data={mainData}
        activeMetrics={activeMetrics}
        showLegend={showLegend}
        benchmarkEnabled={benchmarkEnabled}
      />
    </div>
  );
};