import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';

export const Navigation = () => {
  const navigate = useNavigate();

  return (
    <div className="flex items-center gap-1">
      <button
        onClick={() => navigate(-1)}
        className="p-1.5 hover:bg-gray-100 rounded-full transition-colors"
        title="Go back"
      >
        <ArrowLeft className="text-gray-500 w-4 h-4" />
      </button>
      <button
        onClick={() => navigate(1)}
        className="p-1.5 hover:bg-gray-100 rounded-full transition-colors"
        title="Go forward"
      >
        <ArrowRight className="text-gray-500 w-4 h-4" />
      </button>
    </div>
  );
};