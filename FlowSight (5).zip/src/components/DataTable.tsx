import { useState } from 'react';
import { ChevronUp, ChevronDown } from 'lucide-react';
import { format, parseISO } from 'date-fns';

interface Column<T> {
  header: string;
  accessor: keyof T;
  formatter?: (value: any) => string | number;
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
}

export const DataTable = <T extends object>({ data, columns }: DataTableProps<T>) => {
  const [sortColumn, setSortColumn] = useState<keyof T | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const handleSort = (column: keyof T) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('desc');
    }
  };

  const sortedData = [...data].sort((a, b) => {
    if (!sortColumn) return 0;

    const aValue = a[sortColumn];
    const bValue = b[sortColumn];

    if (aValue === bValue) return 0;
    if (aValue === null || aValue === undefined) return 1;
    if (bValue === null || bValue === undefined) return -1;

    const comparison = aValue < bValue ? -1 : 1;
    return sortDirection === 'asc' ? comparison : -comparison;
  });

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white rounded-lg shadow-sm">
        <thead>
          <tr className="border-b">
            {columns.map((column) => (
              <th
                key={String(column.accessor)}
                className="px-6 py-3 text-left text-sm font-semibold text-gray-600 cursor-pointer hover:bg-gray-50"
                onClick={() => handleSort(column.accessor)}
              >
                <div className="flex items-center space-x-1">
                  <span>{column.header}</span>
                  <div className="flex flex-col">
                    <ChevronUp
                      size={14}
                      className={`${
                        sortColumn === column.accessor && sortDirection === 'asc'
                          ? 'text-primary'
                          : 'text-gray-400'
                      }`}
                    />
                    <ChevronDown
                      size={14}
                      className={`${
                        sortColumn === column.accessor && sortDirection === 'desc'
                          ? 'text-primary'
                          : 'text-gray-400'
                      }`}
                    />
                  </div>
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sortedData.map((row, index) => (
            <tr
              key={index}
              className="border-b hover:bg-gray-50 transition-colors"
            >
              {columns.map((column) => (
                <td
                  key={String(column.accessor)}
                  className="px-6 py-4 text-sm text-gray-700 whitespace-nowrap"
                >
                  {column.formatter
                    ? column.formatter(row[column.accessor])
                    : String(row[column.accessor])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};