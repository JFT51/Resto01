import { VisitorTrafficChart } from '../charts/VisitorTrafficChart';

interface TimeSeriesChartProps {
  data: any[];
  activeMetrics: string[];
  showLegend?: boolean;
  isDailyData?: boolean;
  benchmarkEnabled?: boolean;
}

export const TimeSeriesChart = (props: TimeSeriesChartProps) => {
  return <VisitorTrafficChart {...props} />;
};