import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { CustomTooltip } from '../charts/components/CustomTooltip';

interface HourlyWeekChartProps {
  data: Array<{
    hour: string;
    monday: number;
    tuesday: number;
    wednesday: number;
    thursday: number;
    friday: number;
    saturday: number;
    sunday: number;
  }>;
  showLegend?: boolean;
}

const DAYS_CONFIG = [
  { key: 'monday', name: 'Monday', color: '#4D8B31' },     // Primary green
  { key: 'tuesday', name: 'Tuesday', color: '#FF8811' },   // Secondary orange
  { key: 'wednesday', name: 'Wednesday', color: '#2A4E1E' },// Dark green
  { key: 'thursday', name: 'Thursday', color: '#6366f1' }, // Indigo
  { key: 'friday', name: 'Friday', color: '#ec4899' },     // Pink
  { key: 'saturday', name: 'Saturday', color: '#8b5cf6' }, // Purple
  { key: 'sunday', name: 'Sunday', color: '#f59e0b' },     // Amber
];

// Custom Legend component
const CustomLegend = (props: any) => {
  const { payload } = props;
  
  return (
    <ul className="flex flex-wrap gap-6 justify-center mt-4">
      {payload.map((entry: any, index: number) => (
        <li
          key={`item-${index}`}
          className="flex items-center gap-2"
        >
          <span
            className="font-bold"
            style={{ color: entry.color }}
          >
            {entry.value}
          </span>
        </li>
      ))}
    </ul>
  );
};

export const HourlyWeekChart = ({ data, showLegend = true }: HourlyWeekChartProps) => {
  if (!data || data.length === 0) {
    return <div className="h-64 flex items-center justify-center text-gray-500">No data available</div>;
  }

  return (
    <div style={{ width: '100%', height: '400px' }}>
      <ResponsiveContainer>
        <LineChart
          data={data}
          margin={{ top: 20, right: 30, left: 0, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="hour" />
          <YAxis />
          <Tooltip content={<CustomTooltip />} />
          {showLegend && <Legend content={<CustomLegend />} />}
          
          {DAYS_CONFIG.map(day => (
            <Line
              key={day.key}
              type="monotone"
              dataKey={day.key}
              name={day.name}
              stroke={day.color}
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 6 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};