import { ReactNode } from 'react';

interface CardProps {
  title: string;
  value: string;
  icon: ReactNode;
  change: string;
  iconColorClass: string;
}

export const Card = ({ title, value, icon, change, iconColorClass }: CardProps) => {
  const isPositive = change.startsWith('+');

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <span className="text-gray-500">{title}</span>
        <div className={iconColorClass}>
          {icon}
        </div>
      </div>
      <div className="flex items-end justify-between">
        <span className="text-2xl font-bold">{value}</span>
        <span
          className={`text-sm ${
            isPositive ? 'text-green-500' : 'text-red-500'
          }`}
        >
          {change}
        </span>
      </div>
    </div>
  );
};