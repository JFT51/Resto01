import { useState, useMemo } from 'react';
import * as Slider from '@radix-ui/react-slider';

interface PeriodData {
  timestamp: string;
  captureRate: number;
}

interface PeriodCaptureHorizontalChartProps {
  data: PeriodData[];
  benchmarkData?: PeriodData[];
  showBenchmark?: boolean;
}

interface TimePeriod {
  name: string;
  timeRange: string;
  startTime: string;
  endTime: string;
  value: number;
  benchmarkValue?: number;
  color: string;
}

const PERIOD_COLORS = {
  morning: '#4D8B31',    // Morning period - Green
  lunch: '#FF8811',      // Lunch period - Orange
  afternoon: '#2A4E1E',  // Afternoon period - Dark Green
  custom: '#6366f1',     // Custom period - Indigo
};

export const PeriodCaptureHorizontalChart = ({ 
  data, 
  benchmarkData,
  showBenchmark = false 
}: PeriodCaptureHorizontalChartProps) => {
  const [customPeriod, setCustomPeriod] = useState<[number, number]>([11, 15]);

  const calculatePeriodCaptureRate = (startTime: string, endTime: string, sourceData: PeriodData[]): number => {
    const periodData = sourceData.filter(item => {
      const time = item.timestamp.split(' ')[1];
      return time >= startTime && time <= endTime;
    });

    if (periodData.length === 0) return 0;

    const avgCaptureRate = periodData.reduce((sum, item) => sum + item.captureRate, 0) / periodData.length;
    return Number(avgCaptureRate.toFixed(2));
  };

  const periods = useMemo(() => {
    const customStartTime = `${String(customPeriod[0]).padStart(2, '0')}:00`;
    const customEndTime = `${String(customPeriod[1]).padStart(2, '0')}:00`;

    return [
      {
        name: 'Morning Period',
        timeRange: '07:00 - 10:00',
        startTime: '07:00',
        endTime: '10:00',
        value: calculatePeriodCaptureRate('07:00', '10:00', data),
        benchmarkValue: benchmarkData ? calculatePeriodCaptureRate('07:00', '10:00', benchmarkData) : undefined,
        color: PERIOD_COLORS.morning,
      },
      {
        name: 'Lunch Period',
        timeRange: '12:00 - 14:00',
        startTime: '12:00',
        endTime: '14:00',
        value: calculatePeriodCaptureRate('12:00', '14:00', data),
        benchmarkValue: benchmarkData ? calculatePeriodCaptureRate('12:00', '14:00', benchmarkData) : undefined,
        color: PERIOD_COLORS.lunch,
      },
      {
        name: 'Afternoon Period',
        timeRange: '16:00 - 20:00',
        startTime: '16:00',
        endTime: '20:00',
        value: calculatePeriodCaptureRate('16:00', '20:00', data),
        benchmarkValue: benchmarkData ? calculatePeriodCaptureRate('16:00', '20:00', benchmarkData) : undefined,
        color: PERIOD_COLORS.afternoon,
      },
      {
        name: 'Custom Period',
        timeRange: `${customStartTime} - ${customEndTime}`,
        startTime: customStartTime,
        endTime: customEndTime,
        value: calculatePeriodCaptureRate(customStartTime, customEndTime, data),
        benchmarkValue: benchmarkData ? calculatePeriodCaptureRate(customStartTime, customEndTime, benchmarkData) : undefined,
        color: PERIOD_COLORS.custom,
      },
    ];
  }, [data, benchmarkData, customPeriod]);

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-700 mb-2">Custom Period Selection</h3>
        <div className="w-64">
          <Slider.Root
            className="relative flex items-center select-none touch-none w-full h-5"
            value={customPeriod}
            onValueChange={setCustomPeriod}
            min={0}
            max={23}
            step={1}
          >
            <Slider.Track className="bg-gray-200 relative grow rounded-full h-[3px]">
              <Slider.Range className="absolute bg-primary rounded-full h-full" />
            </Slider.Track>
            {customPeriod.map((value, index) => (
              <Slider.Thumb
                key={index}
                className="block w-5 h-5 bg-white border-2 border-primary rounded-full hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
                aria-label={index === 0 ? "Start time" : "End time"}
              />
            ))}
          </Slider.Root>
          <div className="flex justify-between mt-1 text-sm text-gray-600">
            <span>{`${String(customPeriod[0]).padStart(2, '0')}:00`}</span>
            <span>{`${String(customPeriod[1]).padStart(2, '0')}:00`}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {periods.map((period) => (
          <div
            key={period.name}
            className="flex flex-col items-center p-4 bg-white rounded-lg shadow-sm border-t-4"
            style={{ borderColor: period.color }}
          >
            <div className="text-sm font-medium mb-1">{period.name}</div>
            <div className="flex flex-col items-center">
              <div className="text-2xl font-bold" style={{ color: period.color }}>
                {period.value}%
              </div>
              {showBenchmark && period.benchmarkValue !== undefined && (
                <div className="text-lg text-gray-400 -mt-1">
                  {period.benchmarkValue}%
                </div>
              )}
            </div>
            <div className="text-xs text-gray-500">{period.timeRange}</div>
          </div>
        ))}
      </div>
    </div>
  );
};