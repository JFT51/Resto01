import { Calendar } from 'lucide-react';
import ReactDatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";

interface DateRangePickerProps {
  startDate: string;
  endDate: string;
  onStartDateChange: (date: string) => void;
  onEndDateChange: (date: string) => void;
  showBenchmark?: boolean;
  onBenchmarkChange?: (checked: boolean) => void;
}

export const DateRangePicker = ({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
  showBenchmark = false,
  onBenchmarkChange,
}: DateRangePickerProps) => {
  return (
    <div className="flex items-center gap-4">
      <div className="relative">
        <ReactDatePicker
          selected={startDate ? new Date(startDate) : null}
          onChange={(date) => onStartDateChange(date ? date.toISOString().split('T')[0] : '')}
          dateFormat="yyyy-MM-dd"
          showWeekNumbers
          className="pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
        />
        <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
      </div>

      {showBenchmark && (
        <label className="flex items-center gap-2 text-gray-700">
          <input
            type="checkbox"
            className="w-4 h-4 text-primary rounded border-gray-300 focus:ring-primary"
            onChange={(e) => onBenchmarkChange?.(e.target.checked)}
          />
          Benchmark
        </label>
      )}

      <div className="relative">
        <ReactDatePicker
          selected={endDate ? new Date(endDate) : null}
          onChange={(date) => onEndDateChange(date ? date.toISOString().split('T')[0] : '')}
          dateFormat="yyyy-MM-dd"
          showWeekNumbers
          disabled={!showBenchmark}
          className={`pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent
            ${!showBenchmark ? 'bg-gray-100 cursor-not-allowed' : ''}`}
        />
        <Calendar className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${!showBenchmark ? 'text-gray-300' : 'text-gray-400'}`} size={16} />
      </div>
    </div>
  );
};