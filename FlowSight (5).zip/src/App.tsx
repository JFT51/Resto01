import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Overview from './pages/Overview';
import DailyAnalysis from './pages/DailyAnalysis';
import WeeklyAnalysis from './pages/WeeklyAnalysis';
import CaptureRate from './pages/CaptureRate';
import HourlyData from './pages/HourlyData';
import DailyData from './pages/DailyData';
import './index.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Overview />} />
          <Route path="daily-analysis" element={<DailyAnalysis />} />
          <Route path="weekly" element={<WeeklyAnalysis />} />
          <Route path="capture-rate" element={<CaptureRate />} />
          <Route path="hourly-data" element={<HourlyData />} />
          <Route path="daily-data" element={<DailyData />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;