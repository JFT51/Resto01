import { useState } from 'react';
import { Calendar, BarChart3 } from 'lucide-react';
import { DateRangePicker } from '../components/DateRangePicker';
import { WeeklyTrafficChart } from '../components/WeeklyTrafficChart';
import { HourlyWeekChart } from '../components/HourlyWeekChart';
import { useData } from '../context/DataContext';
import LoadingSpinner from '../components/LoadingSpinner';
import { format, parseISO, startOfWeek, endOfWeek } from 'date-fns';

const WeeklyAnalysis = () => {
  const { dailyData, hourlyData, isLoading, error } = useData();
  
  const firstDate = dailyData.length > 0 ? dailyData[0].timestamp : '';
  const lastDate = dailyData.length > 0 ? dailyData[dailyData.length - 1].timestamp : '';

  const [startDate, setStartDate] = useState(firstDate);
  const [endDate, setEndDate] = useState(lastDate);
  const [activeMetrics, setActiveMetrics] = useState(['visitors', 'passersby', 'captureRate']);

  const getWeeklyData = () => {
    const start = parseISO(startDate);
    const end = parseISO(endDate);
    const weekStart = startOfWeek(start);
    const weekEnd = endOfWeek(end);

    return dailyData.filter(item => {
      const date = parseISO(item.timestamp);
      return date >= weekStart && date <= weekEnd;
    });
  };

  const getHourlyWeekData = () => {
    const weekData: { [key: string]: any } = {};
    
    hourlyData.forEach(item => {
      const [date, time] = item.timestamp.split(' ');
      if (!weekData[time]) {
        weekData[time] = {
          hour: time,
          monday: 0,
          tuesday: 0,
          wednesday: 0,
          thursday: 0,
          friday: 0,
          saturday: 0,
          sunday: 0,
        };
      }
      
      const dayOfWeek = format(parseISO(date), 'EEEE').toLowerCase();
      weekData[time][dayOfWeek] = item.visitors;
    });

    return Object.values(weekData);
  };

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="text-red-500">{error}</div>;

  const weeklyData = getWeeklyData();
  const hourlyWeekData = getHourlyWeekData();

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <h1 className="text-3xl font-bold text-gray-800">Weekly Analysis</h1>
        
        <DateRangePicker
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
        />
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Weekly Traffic Pattern</h2>
          <BarChart3 className="text-[#4D8B31]" />
        </div>
        <WeeklyTrafficChart
          data={weeklyData}
          activeMetrics={activeMetrics}
          showLegend={true}
        />
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Hourly Distribution by Day</h2>
          <Calendar className="text-[#4D8B31]" />
        </div>
        <HourlyWeekChart
          data={hourlyWeekData}
          showLegend={true}
        />
      </div>
    </div>
  );
};

export default WeeklyAnalysis;