import { Users, UserPlus, Percent, BarChart3, Trophy, Target, UsersIcon } from 'lucide-react';
import { Card } from '../components/Card';
import { TopDaysCard } from '../components/TopDaysCard';
import { TimeSeriesChart } from '../components/TimeSeriesChart';
import { useData } from '../context/DataContext';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorDisplay from '../components/ErrorDisplay';
import { format, subDays } from 'date-fns';

const Overview = () => {
  const { dailyData, isLoading, error, retryFetch } = useData();

  if (isLoading) return <LoadingSpinner />;
  if (error) return <ErrorDisplay message={error} onRetry={retryFetch} />;
  if (!dailyData || dailyData.length === 0) {
    return <ErrorDisplay message="No data available" onRetry={retryFetch} />;
  }

  const currentDay = dailyData[dailyData.length - 1];
  const previousDay = dailyData[dailyData.length - 2];
  
  const getPercentageChange = (current: number, previous: number) => {
    if (!previous) return '+0%';
    const change = ((current - previous) / previous) * 100;
    return `${change > 0 ? '+' : ''}${change.toFixed(1)}%`;
  };

  const topVisitorsDays = [...dailyData]
    .sort((a, b) => b.visitors - a.visitors)
    .slice(0, 3);

  const topCaptureRateDays = [...dailyData]
    .sort((a, b) => b.captureRate - a.captureRate)
    .slice(0, 3);

  const lastWeekData = dailyData
    .slice(-7)
    .map(day => ({
      ...day,
      visitorsBenchmark: previousDay?.visitors || 0,
      passersbyBenchmark: previousDay?.passersby || 0,
      captureRateBenchmark: previousDay?.captureRate || 0,
    }));

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Overview</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card
          title="Total Visitors"
          value={currentDay.visitors.toLocaleString()}
          icon={<Users />}
          change={getPercentageChange(currentDay.visitors, previousDay?.visitors)}
          iconColorClass="text-primary"
        />
        <Card
          title="Passersby"
          value={currentDay.passersby.toLocaleString()}
          icon={<UserPlus />}
          change={getPercentageChange(currentDay.passersby, previousDay?.passersby)}
          iconColorClass="text-secondary"
        />
        <Card
          title="Capture Rate"
          value={`${currentDay.captureRate.toFixed(1)}%`}
          icon={<Percent />}
          change={getPercentageChange(currentDay.captureRate, previousDay?.captureRate)}
          iconColorClass="text-green-600"
        />
        <Card
          title="Groups"
          value={currentDay.groups.toLocaleString()}
          icon={<UsersIcon />}
          change={getPercentageChange(currentDay.groups, previousDay?.groups)}
          iconColorClass="text-purple-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TopDaysCard
          title="Top Visitor Days"
          data={topVisitorsDays}
          formatValue={(value) => value.toLocaleString()}
          icon={<Trophy />}
          iconColorClass="text-primary"
        />
        <TopDaysCard
          title="Top Capture Rate Days"
          data={topCaptureRateDays}
          formatValue={(value) => `${value.toFixed(1)}%`}
          icon={<Target />}
          iconColorClass="text-secondary"
        />
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Weekly Performance</h2>
          <BarChart3 className="text-[#4D8B31]" />
        </div>
        <TimeSeriesChart
          data={lastWeekData}
          activeMetrics={['visitors', 'passersby', 'captureRate']}
          showLegend={true}
          isDailyData={true}
          benchmarkEnabled={true}
        />
      </div>
    </div>
  );
};

export default Overview;