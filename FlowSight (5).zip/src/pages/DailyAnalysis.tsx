import { useState } from 'react';
import { BarChart3, Calendar, Users } from 'lucide-react';
import { DateRangePicker } from '../components/DateRangePicker';
import { TimeSeriesChart } from '../components/TimeSeriesChart';
import { PeriodCaptureHorizontalChart } from '../components/PeriodCaptureHorizontalChart';
import { useData } from '../context/DataContext';
import LoadingSpinner from '../components/LoadingSpinner';
import { format, parseISO } from 'date-fns';

const DailyAnalysis = () => {
  const { hourlyData, dailyData, isLoading, error } = useData();
  
  const firstDate = dailyData.length > 0 ? dailyData[0].timestamp : '';
  const lastDate = dailyData.length > 0 ? dailyData[dailyData.length - 1].timestamp : '';

  const [startDate, setStartDate] = useState(firstDate);
  const [endDate, setEndDate] = useState(lastDate);
  const [benchmarkEnabled, setBenchmarkEnabled] = useState(false);
  const [activeMetrics, setActiveMetrics] = useState(['visitors', 'passersby', 'captureRate']);

  const getFilteredData = (date: string) => {
    return hourlyData.filter(item => item.timestamp.startsWith(date));
  };

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="text-red-500">{error}</div>;

  const selectedDayData = dailyData.find(item => item.timestamp === startDate);
  const benchmarkDayData = benchmarkEnabled ? dailyData.find(item => item.timestamp === endDate) : undefined;

  const mainData = getFilteredData(startDate);
  const benchmarkData = benchmarkEnabled ? getFilteredData(endDate) : undefined;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <h1 className="text-3xl font-bold text-gray-800">Daily Analysis</h1>
        
        <DateRangePicker
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
          showBenchmark={true}
          onBenchmarkChange={setBenchmarkEnabled}
        />
      </div>

      {selectedDayData && (
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <div className="text-sm text-gray-600">Visitors</div>
              <div className="text-2xl font-bold">{selectedDayData.visitors.toLocaleString()}</div>
              {benchmarkDayData && (
                <div className="text-sm text-gray-400">{benchmarkDayData.visitors.toLocaleString()}</div>
              )}
            </div>
            <div className="space-y-1">
              <div className="text-sm text-gray-600">Capture Rate</div>
              <div className="text-2xl font-bold">{selectedDayData.captureRate.toFixed(1)}%</div>
              {benchmarkDayData && (
                <div className="text-sm text-gray-400">{benchmarkDayData.captureRate.toFixed(1)}%</div>
              )}
            </div>
            <div className="space-y-1">
              <div className="text-sm text-gray-600">Gender Split</div>
              <div className="text-2xl font-bold">
                {((selectedDayData.men / (selectedDayData.men + selectedDayData.women)) * 100).toFixed(1)}% M
              </div>
              {benchmarkDayData && (
                <div className="text-sm text-gray-400">
                  {((benchmarkDayData.men / (benchmarkDayData.men + benchmarkDayData.women)) * 100).toFixed(1)}% M
                </div>
              )}
            </div>
            <div className="space-y-1">
              <div className="text-sm text-gray-600">Weather</div>
              <div className="text-2xl">
                {String.fromCodePoint(selectedDayData.weather.weatherCode)}
              </div>
              <div className="text-sm text-gray-600">
                {selectedDayData.weather.temperature}°C
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Hourly Traffic</h2>
          <BarChart3 className="text-[#4D8B31]" />
        </div>
        <TimeSeriesChart
          data={mainData}
          activeMetrics={activeMetrics}
          showLegend={true}
          benchmarkEnabled={benchmarkEnabled}
        />
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Period Analysis</h2>
          <Users className="text-[#4D8B31]" />
        </div>
        <PeriodCaptureHorizontalChart
          data={mainData}
          benchmarkData={benchmarkData}
          showBenchmark={benchmarkEnabled}
        />
      </div>
    </div>
  );
};

export default DailyAnalysis;