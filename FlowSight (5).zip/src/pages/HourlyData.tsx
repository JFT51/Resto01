import { Clock } from 'lucide-react';
import { useData } from '../context/DataContext';
import { DataTable } from '../components/DataTable';
import LoadingSpinner from '../components/LoadingSpinner';
import { format, parseISO } from 'date-fns';

const HourlyData = () => {
  const { hourlyData, isLoading, error } = useData();

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="text-red-500">{error}</div>;

  const columns = [
    {
      header: 'Time',
      accessor: 'timestamp' as const,
      formatter: (value: string) => format(parseISO(value), 'dd MMM yyyy HH:mm'),
    },
    {
      header: 'Visitors',
      accessor: 'visitors' as const,
      formatter: (value: number) => value.toLocaleString(),
    },
    {
      header: 'Visitors Leaving',
      accessor: 'visitorsLeaving' as const,
      formatter: (value: number) => value.toLocaleString(),
    },
    {
      header: 'Live Visitors',
      accessor: 'liveVisitors' as const,
      formatter: (value: number) => value.toLocaleString(),
    },
    {
      header: 'Passersby',
      accessor: 'passersby' as const,
      formatter: (value: number) => value.toLocaleString(),
    },
    {
      header: 'Capture Rate',
      accessor: 'captureRate' as const,
      formatter: (value: number) => `${value.toFixed(2)}%`,
    },
    {
      header: 'Men',
      accessor: 'men' as const,
      formatter: (value: number) => value.toLocaleString(),
    },
    {
      header: 'Women',
      accessor: 'women' as const,
      formatter: (value: number) => value.toLocaleString(),
    },
    {
      header: 'Groups',
      accessor: 'groups' as const,
      formatter: (value: number) => value.toLocaleString(),
    },
    {
      header: 'Visitors Accumulated',
      accessor: 'visitorsAccumulated' as const,
      formatter: (value: number) => value.toLocaleString(),
    },
    {
      header: 'Visitors Leaving Accumulated',
      accessor: 'visitorsLeavingAccumulated' as const,
      formatter: (value: number) => value.toLocaleString(),
    },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Hourly Data Analysis</h1>
      
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Hourly Traffic Patterns</h2>
          <Clock className="text-[#4D8B31]" />
        </div>
        <DataTable data={hourlyData} columns={columns} />
      </div>
    </div>
  );
};

export default HourlyData;