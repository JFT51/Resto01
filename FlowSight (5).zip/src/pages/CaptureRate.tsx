import { useState } from 'react';
import { Users } from 'lucide-react';
import { useData } from '../context/DataContext';
import { DateRangePicker } from '../components/DateRangePicker';
import { PeriodCaptureHorizontalChart } from '../components/PeriodCaptureHorizontalChart';
import LoadingSpinner from '../components/LoadingSpinner';

const CaptureRate = () => {
  const { hourlyData, isLoading, error } = useData();
  
  const firstDate = hourlyData.length > 0 ? hourlyData[0].timestamp.split(' ')[0] : '';
  const lastDate = hourlyData.length > 0 ? hourlyData[hourlyData.length - 1].timestamp.split(' ')[0] : '';

  const [startDate, setStartDate] = useState(firstDate);
  const [endDate, setEndDate] = useState(lastDate);
  const [benchmarkEnabled, setBenchmarkEnabled] = useState(false);

  const getFilteredData = (day: string) => {
    return hourlyData.filter(item => {
      const itemDate = item.timestamp.split(' ')[0];
      return itemDate === day;
    });
  };

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="text-red-500">{error}</div>;

  const mainData = getFilteredData(startDate);
  const benchmarkData = benchmarkEnabled ? getFilteredData(endDate) : undefined;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <h1 className="text-3xl font-bold text-gray-800">Capture Rate Analysis</h1>
        
        <DateRangePicker
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
          showBenchmark={true}
          onBenchmarkChange={setBenchmarkEnabled}
        />
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Period Capture Rate</h2>
          <Users className="text-slate-600" />
        </div>
        <PeriodCaptureHorizontalChart
          data={mainData}
          benchmarkData={benchmarkData}
          showBenchmark={benchmarkEnabled}
        />
      </div>
    </div>
  );
};

export default CaptureRate;