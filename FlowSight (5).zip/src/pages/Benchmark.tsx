import { useState, useMemo } from 'react';
import { BarChart, Menu } from 'lucide-react';
import { DateRangePicker } from '../components/DateRangePicker';
import { TimeSeriesChart } from '../components/TimeSeriesChart';
import { useData } from '../context/DataContext';
import { format, parseISO } from 'date-fns';
import LoadingSpinner from '../components/LoadingSpinner';

const Benchmark = () => {
  const { hourlyData, dailyData, isLoading, error } = useData();
  
  const firstDate = hourlyData.length > 0 ? hourlyData[0].timestamp.split(' ')[0] : '';
  const lastDate = hourlyData.length > 0 ? hourlyData[hourlyData.length - 1].timestamp.split(' ')[0] : '';

  const [startDate, setStartDate] = useState(firstDate);
  const [endDate, setEndDate] = useState(lastDate);
  const [benchmarkEnabled, setBenchmarkEnabled] = useState(false);
  const [activeMetrics, setActiveMetrics] = useState<string[]>(['visitors']);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const metrics = [
    { id: 'visitors', label: 'Visitors', color: '#4D8B31' },
    { id: 'passersby', label: 'Passersby', color: '#FF8811' },
    { id: 'captureRate', label: 'Capture Rate', color: '#2A4E1E' },
    { id: 'liveVisitors', label: 'Live Visitors', color: '#2A4E1E' },
    { id: 'men', label: 'Men', color: '#6366f1' },
    { id: 'women', label: 'Women', color: '#ec4899' },
    { id: 'groups', label: 'Groups', color: '#8b5cf6' },
  ];

  const selectedDayData = useMemo(() => {
    return dailyData.find(item => item.timestamp === startDate);
  }, [dailyData, startDate]);

  const previousDayData = useMemo(() => {
    const currentIndex = dailyData.findIndex(item => item.timestamp === startDate);
    return currentIndex > 0 ? dailyData[currentIndex - 1] : null;
  }, [dailyData, startDate]);

  const benchmarkDayData = useMemo(() => {
    return benchmarkEnabled ? dailyData.find(item => item.timestamp === endDate) : null;
  }, [dailyData, endDate, benchmarkEnabled]);

  const filteredHourlyData = useMemo(() => {
    if (!startDate) return [];
    
    let filteredData = hourlyData.filter(item => {
      const itemDate = item.timestamp.split(' ')[0];
      return itemDate === startDate;
    });

    if (benchmarkEnabled && endDate) {
      const benchmarkData = hourlyData.filter(item => {
        const itemDate = item.timestamp.split(' ')[0];
        return itemDate === endDate;
      });
      filteredData = [...filteredData, ...benchmarkData];
    }

    return filteredData;
  }, [hourlyData, startDate, endDate, benchmarkEnabled]);

  const getGenderDistribution = (data: typeof selectedDayData) => {
    if (!data) return 'N/A';
    const total = data.men + data.women;
    if (total === 0) return 'No data';
    const menPercent = (data.men / total * 100).toFixed(1);
    const womenPercent = (data.women / total * 100).toFixed(1);
    return `♂️ ${menPercent}% | ♀️ ${womenPercent}%`;
  };

  const getWeatherInfo = (data: typeof selectedDayData) => {
    if (!data) return 'N/A';
    return `${String.fromCodePoint(data.weather.weatherCode)} ${data.weather.temperature}°C | ${data.weather.precipitation}mm`;
  };

  const getDwellTime = (data: typeof selectedDayData) => {
    if (!data) return 'N/A';
    return `${data.averageDwellTime} min`;
  };

  if (isLoading) return <LoadingSpinner />;
  if (error) return <div className="text-red-500">{error}</div>;

  const toggleMetric = (metricId: string) => {
    setActiveMetrics(prev =>
      prev.includes(metricId)
        ? prev.filter(id => id !== metricId)
        : [...prev, metricId]
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <h1 className="text-3xl font-bold text-gray-800">Benchmark Analysis</h1>
        
        <DateRangePicker
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
          showBenchmark={true}
          onBenchmarkChange={setBenchmarkEnabled}
        />
      </div>

      {/* Data Summary Table */}
      <div className="bg-white rounded-lg shadow-sm overflow-x-auto">
        <table className="min-w-full">
          <thead>
            <tr className="bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              <th className="px-6 py-3">Date</th>
              <th className="px-6 py-3">Visitors</th>
              <th className="px-6 py-3">Capture Rate</th>
              <th className="px-6 py-3">Gender Distribution</th>
              <th className="px-6 py-3">Dwell Time</th>
              <th className="px-6 py-3">Data Accuracy</th>
              <th className="px-6 py-3">Weather</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {selectedDayData && (
              <tr className="text-sm text-gray-900">
                <td className="px-6 py-4">{format(parseISO(selectedDayData.timestamp), 'EEE dd MMM yyyy')}</td>
                <td className="px-6 py-4">{selectedDayData.visitors.toLocaleString()}</td>
                <td className="px-6 py-4">{selectedDayData.captureRate.toFixed(1)}%</td>
                <td className="px-6 py-4">{getGenderDistribution(selectedDayData)}</td>
                <td className="px-6 py-4">{getDwellTime(selectedDayData)}</td>
                <td className="px-6 py-4">{selectedDayData.dataAccuracy.toFixed(1)}%</td>
                <td className="px-6 py-4">{getWeatherInfo(selectedDayData)}</td>
              </tr>
            )}
            {previousDayData && (
              <tr className="text-sm text-gray-500 bg-gray-50">
                <td className="px-6 py-4">{format(parseISO(previousDayData.timestamp), 'EEE dd MMM yyyy')}</td>
                <td className="px-6 py-4">{previousDayData.visitors.toLocaleString()}</td>
                <td className="px-6 py-4">{previousDayData.captureRate.toFixed(1)}%</td>
                <td className="px-6 py-4">{getGenderDistribution(previousDayData)}</td>
                <td className="px-6 py-4">{getDwellTime(previousDayData)}</td>
                <td className="px-6 py-4">{previousDayData.dataAccuracy.toFixed(1)}%</td>
                <td className="px-6 py-4">{getWeatherInfo(previousDayData)}</td>
              </tr>
            )}
            {benchmarkEnabled && benchmarkDayData && (
              <tr className="text-sm text-gray-900 bg-blue-50">
                <td className="px-6 py-4">{format(parseISO(benchmarkDayData.timestamp), 'EEE dd MMM yyyy')}</td>
                <td className="px-6 py-4">{benchmarkDayData.visitors.toLocaleString()}</td>
                <td className="px-6 py-4">{benchmarkDayData.captureRate.toFixed(1)}%</td>
                <td className="px-6 py-4">{getGenderDistribution(benchmarkDayData)}</td>
                <td className="px-6 py-4">{getDwellTime(benchmarkDayData)}</td>
                <td className="px-6 py-4">{benchmarkDayData.dataAccuracy.toFixed(1)}%</td>
                <td className="px-6 py-4">{getWeatherInfo(benchmarkDayData)}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Hourly Performance</h2>
          <div className="flex items-center gap-4">
            <BarChart className="text-[#4D8B31]" />
            <div className="relative">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <Menu className="text-gray-600" />
              </button>
              
              {isMenuOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-10"
                    onClick={() => setIsMenuOpen(false)}
                  />
                  
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-100 z-20">
                    <div className="py-2">
                      {metrics.map(metric => (
                        <label
                          key={metric.id}
                          className="flex items-center px-4 py-2 hover:bg-gray-50 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={activeMetrics.includes(metric.id)}
                            onChange={() => toggleMetric(metric.id)}
                            className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                          />
                          <div className="flex items-center gap-2 ml-3">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: metric.color }}
                            />
                            <span className="text-sm text-gray-600">{metric.label}</span>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
        
        <TimeSeriesChart
          data={filteredHourlyData}
          activeMetrics={activeMetrics}
          showLegend={false}
        />
      </div>
    </div>
  );
};

export default Benchmark;