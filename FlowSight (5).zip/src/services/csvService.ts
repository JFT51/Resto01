import Papa from 'papaparse';
import { format, parse } from 'date-fns';

export interface RawVisitorData {
  timestamp: Date;
  visitorsEntering: number;
  visitorsLeaving: number;
  menEntering: number;
  menLeaving: number;
  womenEntering: number;
  womenLeaving: number;
  groupEntering: number;
  groupLeaving: number;
  passersby: number;
}

const CACHE_KEY = 'visitor_data_cache';
const CACHE_TIMESTAMP_KEY = 'visitor_data_cache_timestamp';
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

// Helper function to add delay between retries
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const validateCSVData = (csvText: string): boolean => {
  // Check if the CSV has a valid header
  const expectedHeaders = [
    'Timestamp', 'Visitors Entering', 'Visitors Leaving',
    'Men Entering', 'Men Leaving', 'Women Entering',
    'Women Leaving', 'Group Entering', 'Group Leaving', 'Passersby'
  ];

  const firstLine = csvText.split('\n')[0];
  const headers = firstLine.split(',').map(h => h.trim());
  
  return headers.length === expectedHeaders.length &&
         headers.every((header, index) => 
           header.toLowerCase() === expectedHeaders[index].toLowerCase());
};

export const fetchAndParseCSV = async (url: string): Promise<RawVisitorData[]> => {
  const maxRetries = 3;
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      // Add a random query parameter to bypass cache
      const cacheBuster = `?t=${Date.now()}`;
      const urlWithCacheBuster = `${url}${cacheBuster}`;

      const response = await fetch(urlWithCacheBuster, {
        headers: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch CSV (HTTP ${response.status}). The data source might be unavailable.`);
      }

      const csvText = await response.text();
      if (!csvText.trim()) {
        throw new Error('The CSV file is empty. Please check the data source.');
      }

      // Validate CSV structure
      if (!validateCSVData(csvText)) {
        throw new Error('The CSV file structure is invalid. Expected columns are missing or in wrong format.');
      }

      return new Promise((resolve, reject) => {
        Papa.parse(csvText, {
          complete: (results) => {
            if (results.errors && results.errors.length > 0) {
              reject(new Error('CSV parsing errors: ' + results.errors.map(e => e.message).join(', ')));
              return;
            }

            const parsedData: RawVisitorData[] = results.data
              .slice(1) // Skip header row
              .filter((row: any[]) => row.length === 10 && row[0]) // Ensure valid rows
              .map((row: any[]) => {
                try {
                  return {
                    timestamp: parse(row[0], 'dd/MM/yyyy H:mm', new Date()),
                    visitorsEntering: parseInt(row[1]) || 0,
                    visitorsLeaving: parseInt(row[2]) || 0,
                    menEntering: parseInt(row[3]) || 0,
                    menLeaving: parseInt(row[4]) || 0,
                    womenEntering: parseInt(row[5]) || 0,
                    womenLeaving: parseInt(row[6]) || 0,
                    groupEntering: parseInt(row[7]) || 0,
                    groupLeaving: parseInt(row[8]) || 0,
                    passersby: parseInt(row[9]) || 0,
                  };
                } catch (error) {
                  console.error('Error parsing row:', row, error);
                  return null;
                }
              })
              .filter((row): row is RawVisitorData => row !== null);

            if (parsedData.length === 0) {
              reject(new Error('No valid data rows found in the CSV file.'));
              return;
            }

            resolve(parsedData);
          },
          error: (error) => {
            reject(new Error('CSV parsing error: ' + error.message));
          },
        });
      });

    } catch (error) {
      lastError = error instanceof Error ? error : new Error('Unknown error occurred');
      console.warn(`Attempt ${attempt + 1} failed:`, lastError.message);
      
      if (attempt < maxRetries - 1) {
        await delay(1000 * Math.pow(2, attempt)); // Exponential backoff
        continue;
      }
    }
  }

  throw new Error(`Unable to access the data source after ${maxRetries} attempts. Please verify that the URL is correct and accessible: ${url}`);
};