import { format } from 'date-fns';

export interface WeatherResponse {
  daily: {
    time: string[];
    temperature_2m_mean: number[];
    precipitation_sum: number[];
    windspeed_10m_max: number[];
    weathercode: number[];
  };
}

export interface ProcessedWeatherData {
  date: string;
  temperature: number;
  precipitation: number;
  windSpeed: number;
  weatherEmoji: string;
}

const weatherCodeToEmoji: Record<number, string> = {
  0: '☀️', // Clear sky
  1: '🌤️', // Mainly clear
  2: '⛅', // Partly cloudy
  3: '☁️', // Overcast
  45: '🌫️', // Foggy
  48: '🌫️', // Depositing rime fog
  51: '🌧️', // Light drizzle
  53: '🌧️', // Moderate drizzle
  55: '🌧️', // Dense drizzle
  61: '🌧️', // Slight rain
  63: '🌧️', // Moderate rain
  65: '🌧️', // Heavy rain
  71: '🌨️', // Slight snow
  73: '🌨️', // Moderate snow
  75: '🌨️', // Heavy snow
  77: '🌨️', // Snow grains
  80: '🌦️', // Slight rain showers
  81: '🌦️', // Moderate rain showers
  82: '🌦️', // Violent rain showers
  85: '🌨️', // Slight snow showers
  86: '🌨️', // Heavy snow showers
  95: '⛈️', // Thunderstorm
  96: '⛈️', // Thunderstorm with slight hail
  99: '⛈️', // Thunderstorm with heavy hail
};

// Fallback data generator
const generateFallbackWeatherData = (startDate: string, endDate: string): ProcessedWeatherData[] => {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  
  return Array.from({ length: days }, (_, index) => {
    const currentDate = new Date(start);
    currentDate.setDate(start.getDate() + index);
    
    return {
      date: format(currentDate, 'yyyy-MM-dd'),
      temperature: 20, // Default comfortable temperature
      precipitation: 0,
      windSpeed: 5,
      weatherEmoji: '☀️', // Default sunny weather
    };
  });
};

export const fetchWeatherData = async (startDate: string, endDate: string): Promise<ProcessedWeatherData[]> => {
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=50.8503&longitude=4.3517&daily=temperature_2m_mean,precipitation_sum,windspeed_10m_max,weathercode&timezone=auto&start_date=${startDate}&end_date=${endDate}`;
    
    const response = await fetch(url);
    
    // Check if response is ok
    if (!response.ok) {
      console.warn('Weather API returned error:', response.status);
      return generateFallbackWeatherData(startDate, endDate);
    }

    const data: WeatherResponse = await response.json();

    // Validate data structure
    if (!data.daily || !Array.isArray(data.daily.time)) {
      console.warn('Invalid weather data structure');
      return generateFallbackWeatherData(startDate, endDate);
    }

    return data.daily.time.map((date, index) => ({
      date,
      temperature: data.daily.temperature_2m_mean[index] ?? 20,
      precipitation: data.daily.precipitation_sum[index] ?? 0,
      windSpeed: data.daily.windspeed_10m_max[index] ?? 5,
      weatherEmoji: weatherCodeToEmoji[data.daily.weathercode[index]] || '☀️',
    }));

  } catch (error) {
    console.warn('Error fetching weather data:', error);
    return generateFallbackWeatherData(startDate, endDate);
  }
};