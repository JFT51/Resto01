export interface HourlyData {
  timestamp: string;
  visitors: number;
  visitorsLeaving: number;
  liveVisitors: number;
  passersby: number;
  captureRate: number;
  men: number;
  women: number;
  groups: number;
  visitorsAccumulated: number;
  visitorsLeavingAccumulated: number;
}

export interface WeatherData {
  temperature: number;
  precipitation: number;
  weatherCode: number;
}

export interface DailyData extends Omit<HourlyData, 'visitorsAccumulated' | 'visitorsLeavingAccumulated'> {
  weather: WeatherData;
  averageDwellTime: number;
  dataAccuracy: number; // New field for data accuracy percentage
}

export interface WeeklyData {
  startDate: string;
  endDate: string;
  avgVisitors: number;
  avgPassersby: number;
  avgCaptureRate: number;
  totalMen: number;
  totalWomen: number;
  totalGroups: number;
}

export interface MonthlyData extends WeeklyData {}