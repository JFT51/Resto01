# FlowSight - Restaurant Analytics Dashboard

A modern analytics dashboard for tracking and analyzing restaurant visitor data. Built with React, TypeScript, and Tailwind CSS.

## Features

- Real-time visitor tracking
- Daily, weekly, and period analysis
- Capture rate visualization
- Weather impact analysis
- Gender distribution tracking
- Comprehensive data tables
- Benchmark comparisons

## Tech Stack

- React with TypeScript
- Vite for build tooling
- Tailwind CSS for styling
- Recharts for data visualization
- React Router for navigation
- Date-fns for date manipulation

## Getting Started

1. Clone the repository
```bash
git clone [your-repo-url]
cd flowsight
```

2. Install dependencies
```bash
npm install
```

3. Start development server
```bash
npm run dev
```

4. Build for production
```bash
npm run build
```

## License

MIT License